SkySpace
========

an implementation of distributed tuple space. Support Java and Python.
